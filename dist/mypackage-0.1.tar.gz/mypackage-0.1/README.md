# mypackage
This library is created for illustrating an example of package
# How to install
...